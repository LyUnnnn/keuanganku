// ─── saldo.js — Panel Saldo Real-Time ────────────────────
// Logika:
//   Saldo per akun = SEMUA waktu (kumulatif, seperti rumus Sheets)
//   Pemasukan & Pengeluaran periode = difilter per bulan yang dipilih
//
// Protokol doGet:
//   GET ?action=saldo&sheetName=Transaksi
//   Response: { status:'ok', data:{ perSumber:[{nama, saldo, perBulan:{'YYYY-MM':{masuk,keluar,txn}}}] } }

const SUMBER_EMOJI = {
  BCA: '🏦', Cash: '💵', OVO: '💜',
  Gopay: '💚', Dana: '🔵', Shopeepay: '🧡', ShopeePay: '🧡',
};

function getSumberEmoji(nama) {
  return SUMBER_EMOJI[nama] || '💳';
}

// State filter bulan aktif — format 'YYYY-MM'
let activeBulan = '';

// ─── Helpers ─────────────────────────────────────────────
function getBulanLabel(yyyyMM) {
  if (!yyyyMM) return '';
  const [y, m] = yyyyMM.split('-');
  return new Date(+y, +m - 1, 1).toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
}

function getCurrentYYYYMM() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

// ─── Fetch dari Sheets ────────────────────────────────────
async function fetchSaldoFromSheets() {
  if (!settings.scriptUrl) throw new Error('URL Apps Script belum diisi.');

  const url = new URL(settings.scriptUrl);
  url.searchParams.set('action', 'saldo');
  url.searchParams.set('sheetName', settings.sheetName || 'Transaksi');

  const res  = await fetch(url.toString(), { cache: 'no-store' });
  const json = await res.json();

  if (json.status !== 'ok') throw new Error(json.message || 'Respons tidak valid dari Sheets');
  return json.data;
}

// ─── Render: Filter Bulan Pills ───────────────────────────
function renderBulanFilter(bulanList) {
  const wrap = document.getElementById('saldo-bulan-filter');
  if (!wrap) return;

  const currentMM = getCurrentYYYYMM();
  if (!activeBulan) activeBulan = currentMM;

  const all = [...new Set([currentMM, ...bulanList])].sort((a, b) => b.localeCompare(a)).slice(0, 12);

  wrap.innerHTML = all.map(mm => {
    const [y, m] = mm.split('-');
    const label  = new Date(+y, +m - 1, 1).toLocaleDateString('id-ID', { month: 'short', year: '2-digit' });
    const active = mm === activeBulan;
    return `<div class="filter-chip ${active ? 'active' : ''}" onclick="setBulanFilter('${mm}')">${label}</div>`;
  }).join('');
}

function setBulanFilter(mm) {
  activeBulan = mm;
  if (window._saldoData) renderSaldoPanel(window._saldoData);
}

// ─── Render: Hero Total ───────────────────────────────────
function renderHero(perSumber, bulan) {
  const totalSaldo  = perSumber.reduce((s, a) => s + (a.saldo ?? 0), 0);
  const periodeData = perSumber.map(a => a.perBulan?.[bulan] || { masuk:0, keluar:0, txn:0 });
  const totalMasuk  = periodeData.reduce((s, d) => s + d.masuk,  0);
  const totalKeluar = periodeData.reduce((s, d) => s + d.keluar, 0);
  const totalTxn    = periodeData.reduce((s, d) => s + d.txn,    0);

  const totalEl  = document.getElementById('saldo-total');
  const subEl    = document.getElementById('saldo-periode');
  if (totalEl) {
    totalEl.textContent = formatRp(totalSaldo);
    totalEl.className   = 'saldo-hero-amount' + (totalSaldo >= 0 ? ' positive' : ' negative');
  }
  if (subEl) subEl.textContent = `Saldo kumulatif semua akun · ${perSumber.length} sumber`;

  const masukEl  = document.getElementById('saldo-masuk');
  const keluarEl = document.getElementById('saldo-keluar');
  const txnEl    = document.getElementById('saldo-txn-total');
  const masukSub = document.getElementById('saldo-masuk-count');
  const keluarSub= document.getElementById('saldo-keluar-count');
  const sheetEl  = document.getElementById('saldo-sheet-name');

  if (masukEl)   masukEl.textContent   = formatRp(totalMasuk);
  if (keluarEl)  keluarEl.textContent  = formatRp(totalKeluar);
  if (txnEl)     txnEl.textContent     = totalTxn;
  if (masukSub)  masukSub.textContent  = `Masuk ${getBulanLabel(bulan)}`;
  if (keluarSub) keluarSub.textContent = `Keluar ${getBulanLabel(bulan)}`;
  if (sheetEl)   sheetEl.textContent   = settings.sheetName || 'Transaksi';
}

// ─── Render: Kartu Per Akun ───────────────────────────────
function renderAkunCards(perSumber, bulan) {
  const listEl = document.getElementById('saldo-sumber-list');
  if (!listEl) return;

  if (!perSumber || perSumber.length === 0) {
    listEl.innerHTML = `
      <div class="saldo-error">
        <div class="saldo-error-icon">📭</div>
        <p>Tidak ada data per sumber.</p>
      </div>`;
    return;
  }

  listEl.innerHTML = perSumber.map(akun => {
    const saldo    = akun.saldo ?? 0;
    const bData    = akun.perBulan?.[bulan] || { masuk: 0, keluar: 0, txn: 0 };
    const masuk    = bData.masuk  ?? 0;
    const keluar   = bData.keluar ?? 0;
    const txn      = bData.txn    ?? 0;
    const emoji    = getSumberEmoji(akun.nama);
    const saldoCls = saldo >= 0 ? 'masuk-color' : 'keluar-color';

    return `
      <div class="akun-card">
        <div class="akun-card-header">
          <div class="akun-card-left">
            <span class="akun-emoji">${emoji}</span>
            <span class="akun-nama">${akun.nama}</span>
            <span class="akun-txn-badge">${txn} txn</span>
          </div>
          <div class="akun-saldo ${saldoCls}">${formatRp(saldo)}</div>
        </div>
        <div class="akun-card-body">
          <div class="akun-row">
            <span class="akun-row-label">↑ Total Pemasukan</span>
            <span class="akun-row-val masuk-color">${formatRp(masuk)}</span>
          </div>
          <div class="akun-row">
            <span class="akun-row-label">↓ Total Pengeluaran</span>
            <span class="akun-row-val keluar-color">${formatRp(keluar)}</span>
          </div>
        </div>
      </div>`;
  }).join('');
}

// ─── Master render ────────────────────────────────────────
function renderSaldoPanel(data) {
  const bulan = activeBulan || getCurrentYYYYMM();

  const allBulan = new Set();
  (data.perSumber || []).forEach(a => {
    Object.keys(a.perBulan || {}).forEach(b => allBulan.add(b));
  });

  renderBulanFilter([...allBulan]);
  renderHero(data.perSumber || [], bulan);
  renderAkunCards(data.perSumber || [], bulan);
}

// ─── Error state ─────────────────────────────────────────
function renderSaldoError(msg) {
  const listEl   = document.getElementById('saldo-sumber-list');
  const totalEl  = document.getElementById('saldo-total');
  const periodeEl= document.getElementById('saldo-periode');
  if (totalEl)   totalEl.textContent   = '—';
  if (periodeEl) periodeEl.textContent = 'Gagal memuat data';
  if (listEl) listEl.innerHTML = `
    <div class="saldo-error">
      <div class="saldo-error-icon">⚠️</div>
      <p>${msg}</p>
    </div>`;
}

// ─── Aksi Refresh ────────────────────────────────────────
async function refreshSaldo() {
  const btn = document.getElementById('saldo-refresh-btn');

  if (!settings.scriptUrl) {
    toast('Isi URL Apps Script di Pengaturan terlebih dahulu!', 'error');
    showPanel('settings');
    return;
  }

  if (btn) btn.classList.add('loading');
  toast('⏳ Memuat saldo dari Sheets...', 'info');

  try {
    const data        = await fetchSaldoFromSheets();
    window._saldoData = data;

    renderSaldoPanel(data);

    const updateEl = document.getElementById('saldo-last-update');
    if (updateEl) {
      updateEl.textContent = 'Diperbarui: ' + new Date().toLocaleString('id-ID', {
        day:'2-digit', month:'2-digit', year:'numeric',
        hour:'2-digit', minute:'2-digit',
      });
    }

    toast('✅ Saldo berhasil dimuat', 'success');
  } catch (err) {
    console.error('refreshSaldo error:', err);
    renderSaldoError(err.message || 'Gagal terhubung ke Google Sheets.');
    toast('❌ ' + (err.message || 'Gagal memuat saldo'), 'error');
  } finally {
    if (btn) btn.classList.remove('loading');
  }
}

// Auto-refresh saat panel dibuka (sekali per sesi)
function onSaldoPanelOpen() {
  if (!settings.scriptUrl) return;
  const lastUpdate = document.getElementById('saldo-last-update');
  if (lastUpdate && lastUpdate.textContent) return;
  refreshSaldo();
}
